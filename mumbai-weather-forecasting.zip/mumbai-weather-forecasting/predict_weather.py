import requests
import joblib
from datetime import datetime

# Load model
model = joblib.load("model/weather_model.pkl")

# Mumbai coordinates
latitude = 19.0760
longitude = 72.8777

# Weather API
url = "https://api.open-meteo.com/v1/forecast"

params = {
    "latitude": latitude,
    "longitude": longitude,
    "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum",
    "timezone": "Asia/Kolkata",
    "forecast_days": 2
}

response = requests.get(url, params=params)

if response.status_code == 200:

    data = response.json()

    daily = data["daily"]

    # Today's weather
    today_max = daily["temperature_2m_max"][0]
    today_min = daily["temperature_2m_min"][0]
    today_rain = daily["precipitation_sum"][0]

    # Tomorrow's date
    tomorrow = datetime.now().date()

    # Features
    month = tomorrow.month
    day_of_year = tomorrow.timetuple().tm_yday

    input_data = [[
        today_max,
        today_min,
        today_rain,
        month,
        day_of_year
    ]]

    # Prediction
    prediction = model.predict(input_data)

    print("\n🌦️ MUMBAI WEATHER PREDICTION")
    print("=" * 45)

    print(f"Today's Maximum Temperature : {today_max} °C")
    print(f"Today's Minimum Temperature : {today_min} °C")
    print(f"Today's Rainfall            : {today_rain} mm")

    print("\n🤖 MACHINE LEARNING PREDICTION")
    print("-" * 45)

    print(
        f"Predicted Maximum Temperature: "
        f"{prediction[0]:.2f} °C"
    )

else:
    print("❌ API Error:", response.status_code)