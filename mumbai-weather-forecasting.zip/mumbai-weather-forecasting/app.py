from flask import Flask, render_template, request
import requests
import joblib
import pandas as pd
from datetime import datetime

app = Flask(__name__)

# Load trained ML model
model = joblib.load("model/weather_model.pkl")


# Available cities
CITIES = {
    "Mumbai": (19.0760, 72.8777),
    "Pune": (18.5204, 73.8567),
    "Delhi": (28.6139, 77.2090),
    "Bengaluru": (12.9716, 77.5946),
    "Chennai": (13.0827, 80.2707),
    "Kolkata": (22.5726, 88.3639),
    "Hyderabad": (17.3850, 78.4867)
}


# --------------------------------
# Get weather from API
# --------------------------------

def get_weather(city):

    latitude, longitude = CITIES[city]

    url = "https://api.open-meteo.com/v1/forecast"

    params = {
        "latitude": latitude,
        "longitude": longitude,

        "current": (
            "temperature_2m,"
            "relative_humidity_2m,"
            "precipitation,"
            "wind_speed_10m"
        ),

        "daily": (
            "temperature_2m_max,"
            "temperature_2m_min,"
            "precipitation_sum"
        ),

        "timezone": "Asia/Kolkata",
        "forecast_days": 7
    }

    try:

        response = requests.get(
            url,
            params=params,
            timeout=15
        )

        print("API Status:", response.status_code)

        response.raise_for_status()

        return response.json()

    except Exception as e:

        print("Weather API Error:", e)

        return None


# --------------------------------
# Weather Icons
# --------------------------------

def get_weather_icon(rainfall):

    if rainfall >= 10:
        return "⛈️"

    elif rainfall > 0:
        return "🌧️"

    else:
        return "☀️"


# --------------------------------
# Home Page
# --------------------------------

@app.route("/")
def home():

    # Get selected city
    city = request.args.get("city", "Mumbai")

    # Check valid city
    if city not in CITIES:
        city = "Mumbai"

    # Get live weather
    data = get_weather(city)

    if data is None:

        return """
        <h2>🌦️ Weather service temporarily unavailable</h2>
        <p>Please refresh the page after a few seconds.</p>
        """


    # Current weather
    current = data["current"]

    # 7-day forecast
    daily = data["daily"]


    # --------------------------------
    # Today's Weather
    # --------------------------------

    today_max = daily["temperature_2m_max"][0]

    today_min = daily["temperature_2m_min"][0]

    today_rain = daily["precipitation_sum"][0]


    # --------------------------------
    # Date Features
    # --------------------------------

    today = datetime.now()

    month = today.month

    day_of_year = today.timetuple().tm_yday


    # --------------------------------
    # Machine Learning Prediction
    # --------------------------------

    input_data = [[

        today_max,

        today_min,

        today_rain,

        month,

        day_of_year

    ]]


    prediction = model.predict(input_data)


    predicted_temperature = round(
        float(prediction[0]),
        2
    )


    # --------------------------------
    # Weather Icons
    # --------------------------------

    weather_icons = []

    for rainfall in daily["precipitation_sum"]:

        weather_icons.append(
            get_weather_icon(rainfall)
        )


    # --------------------------------
    # Send Data to HTML
    # --------------------------------

    return render_template(

        "index.html",

        city=city,

        cities=CITIES.keys(),

        current=current,

        daily=daily,

        predicted_temperature=predicted_temperature,

        weather_icons=weather_icons

    )


# --------------------------------
# Run Flask
# --------------------------------
@app.route("/ml-analysis")
def ml_analysis():

    # Load test predictions
    results = pd.read_csv(
        "model/test_predictions.csv"
    )

    # Load model metrics
    metrics = joblib.load(
        "model/model_metrics.pkl"
    )

    # Convert dates to strings
    dates = results["Date"].astype(str).tolist()

    # Actual temperatures
    actual = (
        results["Max_Temperature"]
        .round(2)
        .tolist()
    )

    # Linear Regression predictions
    linear_predictions = (
        results["Linear_Regression"]
        .round(2)
        .tolist()
    )

    # Random Forest predictions
    random_predictions = (
        results["Random_Forest"]
        .round(2)
        .tolist()
    )

    return render_template(
        "ml_analysis.html",

        dates=dates,

        actual=actual,

        linear_predictions=linear_predictions,

        random_predictions=random_predictions,

        metrics=metrics
    )
    # --------------------------------
# Run Flask
# --------------------------------

if __name__ == "__main__":
    app.run(debug=True)