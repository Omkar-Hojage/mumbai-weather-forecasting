import requests

url = "https://api.open-meteo.com/v1/forecast"

params = {
    "latitude": 19.0760,
    "longitude": 72.8777,
    "current": "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m",
    "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum",
    "timezone": "Asia/Kolkata",
    "forecast_days": 7
}

response = requests.get(url, params=params)

if response.status_code == 200:
    data = response.json()

    # Current weather
    current = data["current"]

    print("\n🌦️ MUMBAI REAL-TIME WEATHER")
    print("=" * 35)

    print(f"Temperature : {current['temperature_2m']} °C")
    print(f"Humidity    : {current['relative_humidity_2m']} %")
    print(f"Rainfall    : {current['precipitation']} mm")
    print(f"Wind Speed  : {current['wind_speed_10m']} km/h")

    # 7-day forecast
    daily = data["daily"]

    print("\n📅 7-DAY FORECAST")
    print("=" * 60)

    for i in range(7):
        print(
            f"{daily['time'][i]} | "
            f"Max: {daily['temperature_2m_max'][i]} °C | "
            f"Min: {daily['temperature_2m_min'][i]} °C | "
            f"Rain: {daily['precipitation_sum'][i]} mm"
        )

else:
    print("❌ Error:", response.status_code)