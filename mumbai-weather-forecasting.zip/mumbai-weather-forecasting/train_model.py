import pandas as pd
import joblib

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)


# ==========================================
# Load Dataset
# ==========================================

df = pd.read_csv("dataset/weather_data.csv")

df["Date"] = pd.to_datetime(df["Date"])

df = df.sort_values("Date")

df = df.dropna()


# ==========================================
# Feature Engineering
# ==========================================

df["Previous_Max_Temp"] = (
    df["Max_Temperature"].shift(1)
)

df["Previous_Min_Temp"] = (
    df["Min_Temperature"].shift(1)
)

df["Previous_Rainfall"] = (
    df["Rainfall"].shift(1)
)


# Seasonal Features

df["Month"] = df["Date"].dt.month

df["Day_of_Year"] = df["Date"].dt.dayofyear


# Remove first row

df = df.dropna()


# ==========================================
# Features
# ==========================================

features = [

    "Previous_Max_Temp",

    "Previous_Min_Temp",

    "Previous_Rainfall",

    "Month",

    "Day_of_Year"

]


# ==========================================
# Train/Test Split
# ==========================================

train_data = df[
    df["Date"] < "2025-01-01"
]

test_data = df[
    df["Date"] >= "2025-01-01"
]


X_train = train_data[features]

y_train = train_data["Max_Temperature"]


X_test = test_data[features]

y_test = test_data["Max_Temperature"]


print("\n🌦️ MUMBAI WEATHER FORECASTING MODEL")

print("=" * 50)

print(
    "Training records:",
    len(X_train)
)

print(
    "Testing records :",
    len(X_test)
)


# ==========================================
# Linear Regression
# ==========================================

lr_model = LinearRegression()

lr_model.fit(
    X_train,
    y_train
)

lr_predictions = lr_model.predict(
    X_test
)


lr_mae = mean_absolute_error(
    y_test,
    lr_predictions
)

lr_mse = mean_squared_error(
    y_test,
    lr_predictions
)

lr_rmse = lr_mse ** 0.5

lr_r2 = r2_score(
    y_test,
    lr_predictions
)


print("\n📊 LINEAR REGRESSION")

print("-" * 40)

print(
    f"MAE  : {lr_mae:.2f} °C"
)

print(
    f"RMSE : {lr_rmse:.2f} °C"
)

print(
    f"R²   : {lr_r2:.2f}"
)


# ==========================================
# Random Forest
# ==========================================

rf_model = RandomForestRegressor(

    n_estimators=200,

    random_state=42

)


rf_model.fit(
    X_train,
    y_train
)

rf_predictions = rf_model.predict(
    X_test
)


rf_mae = mean_absolute_error(
    y_test,
    rf_predictions
)

rf_mse = mean_squared_error(
    y_test,
    rf_predictions
)

rf_rmse = rf_mse ** 0.5

rf_r2 = r2_score(
    y_test,
    rf_predictions
)


print("\n🌲 RANDOM FOREST")

print("-" * 40)

print(
    f"MAE  : {rf_mae:.2f} °C"
)

print(
    f"RMSE : {rf_rmse:.2f} °C"
)

print(
    f"R²   : {rf_r2:.2f}"
)


# ==========================================
# Save Test Predictions
# ==========================================

results = test_data[
    ["Date", "Max_Temperature"]
].copy()


results["Linear_Regression"] = (
    lr_predictions
)

results["Random_Forest"] = (
    rf_predictions
)


results.to_csv(
    "model/test_predictions.csv",
    index=False
)


print(
    "\n📊 Test predictions saved!"
)

print(
    "📁 model/test_predictions.csv"
)


# ==========================================
# Save Model Metrics
# ==========================================

metrics = {

    "Linear Regression": {

        "MAE": lr_mae,

        "RMSE": lr_rmse,

        "R2": lr_r2

    },

    "Random Forest": {

        "MAE": rf_mae,

        "RMSE": rf_rmse,

        "R2": rf_r2

    }

}


joblib.dump(
    metrics,
    "model/model_metrics.pkl"
)


print(
    "📁 model/model_metrics.pkl"
)


# ==========================================
# Select Best Model
# ==========================================

if lr_mae <= rf_mae:

    best_model = lr_model

    best_model_name = (
        "Linear Regression"
    )

else:

    best_model = rf_model

    best_model_name = (
        "Random Forest"
    )


print("\n🏆 BEST MODEL")

print("-" * 40)

print(best_model_name)


# ==========================================
# Save Best Model
# ==========================================

joblib.dump(
    best_model,
    "model/weather_model.pkl"
)


# Save Feature Names

joblib.dump(
    features,
    "model/features.pkl"
)


print(
    "\n✅ Best model saved!"
)

print(
    "📁 model/weather_model.pkl"
)